#include < stdio.h >

int main(){puts("Bubble Sort: Best O(n) optimized, Average O(n^2), Worst O(n^2)");puts("Selection Sort: Best / Average / Worst O(n^2)");puts("Insertion Sort: Best O(n), Average / Worst O(n^2)");puts("In - place versions: O(1) extra space");return 0;}

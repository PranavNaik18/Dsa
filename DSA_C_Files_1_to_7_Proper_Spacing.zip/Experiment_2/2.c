#include < stdio.h >

void bubble(int a[],int n){for(int i = 0;i < n - 1;i + + )for(int j = 0;j < n - 1 - i;j + + )if(a[j] > a[j + 1]){int t = a[j];a[j] = a[j + 1];a[j + 1] = t;}}
void selection(int a[],int n){for(int i = 0;i < n - 1;i + + ){int m = i;for(int j = i + 1;j < n;j + + )if(a[j] < a[m])m = j;int t = a[i];a[i] = a[m];a[m] = t;}}
int main(){int a[100],b[100],n;scanf("%d",&n);for(int i = 0;i < n;i + + ){scanf("%d",&a[i]);b[i] = a[i];}bubble(a,n);selection(b,n);printf("Bubble: ");for(int i = 0;i < n;i + + )printf("%d ",a[i]);printf("\nSelection: ");for(int i = 0;i < n;i + + )printf("%d ",b[i]);return 0;}

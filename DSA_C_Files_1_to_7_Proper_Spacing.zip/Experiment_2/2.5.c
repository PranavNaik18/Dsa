#include < stdio.h >

struct Student{int roll;char name[30];float cgpa;};
int main(){struct Student s[100],t;int n;scanf("%d",&n);for(int i = 0;i < n;i + + )scanf("%d %29s %f",&s[i].roll,s[i].name,&s[i].cgpa);for(int i = 0;i < n - 1;i + + ){int m = i;for(int j = i + 1;j < n;j + + )if(s[j].cgpa > s[m].cgpa)m = j;t = s[i];s[i] = s[m];s[m] = t;}for(int i = 0;i < n;i + + )printf("%d %s %.2f\n",s[i].roll,s[i].name,s[i].cgpa);return 0;}

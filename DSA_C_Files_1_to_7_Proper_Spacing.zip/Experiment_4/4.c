#include < stdio.h >

#define N 5
int s[N],top = - 1,q[N],front = - 1,rear = - 1;
void push(int x){if(top = = N - 1)puts("Stack Overflow");else s[ + + top] = x;} void pop(){if(top < 0)puts("Stack Underflow");else printf("Pop = %d\n",s[top - - ]);} void speek(){if(top < 0)puts("Empty");else printf("Stack Peek = %d\n",s[top]);} void sd(){for(int i = top;i > = 0;i - - )printf("%d ",s[i]);puts("");}
void enq(int x){if((rear + 1)%N = = front)puts("Queue Full");else{if(front = = - 1)front = rear = 0;else rear = (rear + 1)%N;q[rear] = x;}} void deq(){if(front = = - 1)puts("Queue Empty");else{printf("Dequeue = %d\n",q[front]);if(front = = rear)front = rear = - 1;else front = (front + 1)%N;}} void qp(){if(front = = - 1)puts("Empty");else printf("Queue Peek = %d\n",q[front]);} void qd(){if(front = = - 1){puts("Empty");return;}int i = front;while(1){printf("%d ",q[i]);if(i = = rear)break;i = (i + 1)%N;}puts("");}
int main(){int c,x;do{printf("1 Push 2 Pop 3 SPeek 4 SDisplay 5 Enqueue 6 Dequeue 7 QPeek 8 QDisplay 9 Exit: ");scanf("%d",&c);if(c = = 1){scanf("%d",&x);push(x);}else if(c = = 2)pop();else if(c = = 3)speek();else if(c = = 4)sd();else if(c = = 5){scanf("%d",&x);enq(x);}else if(c = = 6)deq();else if(c = = 7)qp();else if(c = = 8)qd();}while(c! = 9);return 0;}

#include < stdio.h >

#include < string.h >

int main(){char names[100][50],key[50];int n,l,h,m,found = - 1;printf("Enter number of names: ");scanf("%d",&n);printf("Enter names in alphabetical order:\n");for(int i = 0;i < n;i + + )scanf("%49s",names[i]);printf("Enter name: ");scanf("%49s",key);l = 0;h = n - 1;while(l < = h){m = (l + h) / 2;int c = strcmp(names[m],key);if(c = = 0){found = m;break;}if(c < 0)l = m + 1;else h = m - 1;}if(found > = 0)printf("Found at position %d\n",found + 1);else puts("Not found");return 0;}

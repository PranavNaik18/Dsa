#include < stdio.h >

int linearSearch(int a[],int n,int key,int * c){ * c = 0;for(int i = 0;i < n;i + + ){( * c) + + ;if(a[i] = = key)return i;}return - 1;}
int binarySearch(int a[],int n,int key,int * c){int l = 0,h = n - 1; * c = 0;while(l < = h){int m = (l + h) / 2;( * c) + + ;if(a[m] = = key)return m;if(a[m] < key)l = m + 1;else h = m - 1;}return - 1;}
int main(){int a[100],n,key,c1,c2;printf("Enter n: ");scanf("%d",&n);printf("Enter sorted elements: ");for(int i = 0;i < n;i + + )scanf("%d",&a[i]);printf("Enter key: ");scanf("%d",&key);printf("Linear index = %d comparisons = %d\n",linearSearch(a,n,key,&c1),c1);printf("Binary index = %d comparisons = %d\n",binarySearch(a,n,key,&c2),c2);return 0;}

#include < stdio.h >

#include < ctype.h >

#define MAX 100
int p(char c){if(c = = '^')return 3;if(c = = ' * '||c = = ' / '||c = = '%')return 2;if(c = = ' + '||c = = ' - ')return 1;return 0;}
int calc(int a,int b,char op){if(op = = ' + ')return a + b;if(op = = ' - ')return a - b;if(op = = ' * ')return a * b;if(op = = ' / ')return a / b;return a%b;}
int main(){char in[MAX],post[MAX],op[MAX];int st[MAX],top = - 1,vt = - 1,k = 0;scanf("%99s",in);for(int i = 0;in[i];i + + ){char c = in[i];if(isdigit(c))post[k + + ] = c;else if(c = = '(')op[ + + top] = c;else if(c = = ')'){while(top > = 0&&op[top]! = '(')post[k + + ] = op[top - - ];if(top > = 0)top - - ;}else{while(top > = 0&&op[top]! = '('&&p(op[top]) > = p(c))post[k + + ] = op[top - - ];op[ + + top] = c;}}while(top > = 0)post[k + + ] = op[top - - ];post[k] = '\0';for(int i = 0;post[i];i + + )if(isdigit(post[i]))st[ + + vt] = post[i] - '0';else{int b = st[vt - - ],a = st[vt - - ];st[ + + vt] = calc(a,b,post[i]);}printf("Postfix = %s\nResult = %d\n",post,st[vt]);return 0;}

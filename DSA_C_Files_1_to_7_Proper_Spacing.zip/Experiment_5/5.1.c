#include < stdio.h >

#include < ctype.h >

#include < string.h >

#define MAX 100
int calc(int a,int b,char op){if(op = = ' + ')return a + b;if(op = = ' - ')return a - b;if(op = = ' * ')return a * b;if(op = = ' / ')return a / b;return a%b;}
int main(){char s[MAX];int st[MAX],top = - 1;scanf("%99s",s);for(int i = (int)strlen(s) - 1;i > = 0;i - - ){if(isdigit(s[i]))st[ + + top] = s[i] - '0';else{int a = st[top - - ],b = st[top - - ];st[ + + top] = calc(a,b,s[i]);}}printf("Result = %d\n",st[top]);return 0;}

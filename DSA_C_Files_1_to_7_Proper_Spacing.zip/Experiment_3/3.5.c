#include < stdio.h >

int main(){int marks[50][5],a[250],n,student,subject;scanf("%d",&n);for(int i = 0;i < n;i + + )for(int j = 0;j < 5;j + + ){scanf("%d",&marks[i][j]);a[i * 5 + j] = marks[i][j];}printf("1 - D array: ");for(int i = 0;i < n * 5;i + + )printf("%d ",a[i]);printf("\nEnter student index and subject index: ");scanf("%d%d",&student,&subject);printf("Mark = %d\n",a[student * 5 + subject]);return 0;}

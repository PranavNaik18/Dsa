#include < stdio.h >

int main(){int a[10][10],row[100],col[100],r,c,k = 0;scanf("%d%d",&r,&c);for(int i = 0;i < r;i + + )for(int j = 0;j < c;j + + )scanf("%d",&a[i][j]);for(int i = 0;i < r;i + + )for(int j = 0;j < c;j + + )row[k + + ] = a[i][j];k = 0;for(int j = 0;j < c;j + + )for(int i = 0;i < r;i + + )col[k + + ] = a[i][j];printf("Row - major: ");for(int i = 0;i < r * c;i + + )printf("%d ",row[i]);printf("\nColumn - major: ");for(int i = 0;i < r * c;i + + )printf("%d ",col[i]);return 0;}

#include < stdio.h >

struct Term{int row,col,value;};
int main(){int a[20][20],r,c,k = 0;struct Term t[400];scanf("%d%d",&r,&c);for(int i = 0;i < r;i + + )for(int j = 0;j < c;j + + )scanf("%d",&a[i][j]);for(int i = 0;i < r;i + + )for(int j = 0;j < c;j + + )if(a[i][j]){t[k].row = i;t[k].col = j;t[k].value = a[i][j];k + + ;}for(int i = 0;i < k;i + + )printf("%d %d %d\n",t[i].row,t[i].col,t[i].value);return 0;}

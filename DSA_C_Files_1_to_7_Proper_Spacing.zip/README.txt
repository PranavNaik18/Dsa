DSA LAB — C PROGRAM FILES (EXPERIMENTS 1 TO 7)
Naming:
1.c = Experiment 1 Sample Program
1.1.c, 1.2.c ... = Experiment 1 Exercises
2.c = Experiment 2 Sample Program
...
5.c = Experiment 5 Sample Program
...
7.c = Experiment 7 Sample Program

Compile:
gcc 1.c -o 1
Run:
./1       (Linux/macOS)
1.exe     (Windows)

All files are separate executable C source files.

#include < stdio.h >

#include < stdlib.h >

struct Node{int data;struct Node * next;};struct Node * top = NULL, * front = NULL, * rear = NULL;
void push(int x){struct Node * n = malloc(sizeof( * n));n - > data = x;n - > next = top;top = n;} void pop(){if(!top)puts("Stack Empty");else{struct Node * t = top;printf("Pop = %d\n",t - > data);top = t - > next;free(t);}} void sdisplay(){for(struct Node * t = top;t;t = t - > next)printf("%d ",t - > data);puts("");}
void enqueue(int x){struct Node * n = malloc(sizeof( * n));n - > data = x;n - > next = NULL;if(!rear)front = rear = n;else{rear - > next = n;rear = n;}} void dequeue(){if(!front)puts("Queue Empty");else{struct Node * t = front;printf("Dequeue = %d\n",t - > data);front = t - > next;if(!front)rear = NULL;free(t);}} void qdisplay(){for(struct Node * t = front;t;t = t - > next)printf("%d ",t - > data);puts("");}
int main(){int c,x;do{printf("1 Push 2 Pop 3 Stack Display 4 Enqueue 5 Dequeue 6 Queue Display 7 Exit: ");scanf("%d",&c);if(c = = 1){scanf("%d",&x);push(x);}else if(c = = 2)pop();else if(c = = 3)sdisplay();else if(c = = 4){scanf("%d",&x);enqueue(x);}else if(c = = 5)dequeue();else if(c = = 6)qdisplay();}while(c! = 7);return 0;}

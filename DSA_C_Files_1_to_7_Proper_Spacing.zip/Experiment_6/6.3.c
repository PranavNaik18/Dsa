#include < stdio.h >

#include < stdlib.h >

#include < string.h >

struct Node{char action[100];struct Node * next;};
int main(){struct Node * top = NULL;int c;char x[100];do{printf("1 Action 2 Undo 3 Display 4 Exit: ");scanf("%d",&c);if(c = = 1){struct Node * n = malloc(sizeof( * n));scanf(" %99[^\n]",x);strcpy(n - > action,x);n - > next = top;top = n;}else if(c = = 2){if(!top)puts("Nothing to undo");else{struct Node * t = top;printf("Undo: %s\n",t - > action);top = t - > next;free(t);}}else if(c = = 3)for(struct Node * t = top;t;t = t - > next)puts(t - > action);}while(c! = 4);return 0;}

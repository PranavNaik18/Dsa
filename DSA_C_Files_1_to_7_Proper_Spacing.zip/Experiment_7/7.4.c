#include < stdio.h >

#include < stdlib.h >

struct Node{int d;struct Node * l, * r;};struct Node * ins(struct Node * r,int x){if(!r){r = malloc(sizeof( * r));r - > d = x;r - > l = r - > r = NULL;return r;}if(x < r - > d)r - > l = ins(r - > l,x);else if(x > r - > d)r - > r = ins(r - > r,x);return r;}void pre(struct Node * r){if(r){printf("%d ",r - > d);pre(r - > l);pre(r - > r);}}void in(struct Node * r){if(r){in(r - > l);printf("%d ",r - > d);in(r - > r);}}void post(struct Node * r){if(r){post(r - > l);post(r - > r);printf("%d ",r - > d);}}int main(){struct Node * r = NULL;int n,x;scanf("%d",&n);while(n - - ){scanf("%d",&x);r = ins(r,x);}printf("Preorder: ");pre(r);printf("\nInorder: ");in(r);printf("\nPostorder: ");post(r);puts("");return 0;}

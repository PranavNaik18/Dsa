#include < stdio.h >

#include < stdlib.h >

struct Node{int d;struct Node * l, * r;};struct Node * ins(struct Node * r,int x){if(!r){r = malloc(sizeof( * r));r - > d = x;r - > l = r - > r = NULL;return r;}if(x < r - > d)r - > l = ins(r - > l,x);else if(x > r - > d)r - > r = ins(r - > r,x);return r;}int bst(struct Node * r,int x,int * c){while(r){( * c) + + ;if(r - > d = = x)return 1;r = x < r - > d?r - > l:r - > r;}return 0;}int bin(int a[],int n,int x,int * c){int l = 0,h = n - 1;while(l < = h){int m = (l + h) / 2;( * c) + + ;if(a[m] = = x)return 1;if(a[m] < x)l = m + 1;else h = m - 1;}return 0;}int main(){int a[100],n,x,c1 = 0,c2 = 0;struct Node * r = NULL;scanf("%d",&n);for(int i = 0;i < n;i + + ){scanf("%d",&a[i]);r = ins(r,a[i]);}scanf("%d",&x);bst(r,x,&c1);bin(a,n,x,&c2);printf("BST comparisons = %d\nBinary Search comparisons = %d\n",c1,c2);return 0;}

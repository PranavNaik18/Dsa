#include < stdio.h >

#include < stdlib.h >

struct Node{int d;struct Node * l, * r;};struct Node * ins(struct Node * r,int x){if(!r){r = malloc(sizeof( * r));r - > d = x;r - > l = r - > r = NULL;return r;}if(x < r - > d)r - > l = ins(r - > l,x);else if(x > r - > d)r - > r = ins(r - > r,x);return r;}int height(struct Node * r){if(!r)return 0;int a = height(r - > l),b = height(r - > r);return 1 + (a > b?a:b);}int main(){struct Node * r = NULL;int n,x;scanf("%d",&n);while(n - - ){scanf("%d",&x);r = ins(r,x);}printf("Height = %d\n",height(r));return 0;}

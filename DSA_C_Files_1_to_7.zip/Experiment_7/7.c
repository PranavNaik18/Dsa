#include <stdio.h>
#include <stdlib.h>
struct Node{int data;struct Node*left,*right;};
struct Node*newNode(int x){struct Node*n=malloc(sizeof(*n));n->data=x;n->left=n->right=NULL;return n;}
struct Node*insert(struct Node*r,int x){if(!r)return newNode(x);if(x<r->data)r->left=insert(r->left,x);else if(x>r->data)r->right=insert(r->right,x);return r;}
void inorder(struct Node*r){if(r){inorder(r->left);printf("%d ",r->data);inorder(r->right);}}
struct Node*search(struct Node*r,int x){if(!r||r->data==x)return r;return x<r->data?search(r->left,x):search(r->right,x);}
struct Node*minNode(struct Node*r){while(r->left)r=r->left;return r;}
struct Node*deleteNode(struct Node*r,int x){if(!r)return r;if(x<r->data)r->left=deleteNode(r->left,x);else if(x>r->data)r->right=deleteNode(r->right,x);else{if(!r->left){struct Node*t=r->right;free(r);return t;}if(!r->right){struct Node*t=r->left;free(r);return t;}struct Node*t=minNode(r->right);r->data=t->data;r->right=deleteNode(r->right,t->data);}return r;}
int main(){struct Node*root=NULL;int c,x;do{printf("1 Insert 2 Delete 3 Search 4 Inorder 5 Exit: ");scanf("%d",&c);if(c==1){scanf("%d",&x);root=insert(root,x);}else if(c==2){scanf("%d",&x);root=deleteNode(root,x);}else if(c==3){scanf("%d",&x);puts(search(root,x)?"Found":"Not Found");}else if(c==4){inorder(root);puts("");}}while(c!=5);return 0;}

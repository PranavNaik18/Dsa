#include <stdio.h>
#include <stdlib.h>
struct Node{int d;struct Node*l,*r;};struct Node*ins(struct Node*r,int x){if(!r){r=malloc(sizeof(*r));r->d=x;r->l=r->r=NULL;return r;}if(x<r->d)r->l=ins(r->l,x);else if(x>r->d)r->r=ins(r->r,x);return r;}void count(struct Node*r,int*l,int*i){if(!r)return;if(!r->l&&!r->r)(*l)++;else(*i)++;count(r->l,l,i);count(r->r,l,i);}int main(){struct Node*r=NULL;int n,x,l=0,i=0;scanf("%d",&n);while(n--){scanf("%d",&x);r=ins(r,x);}count(r,&l,&i);printf("Leaf nodes=%d\nInternal nodes=%d\n",l,i);return 0;}

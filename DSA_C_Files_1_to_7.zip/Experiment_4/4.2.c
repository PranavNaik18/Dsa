#include <stdio.h>
#define N 50
int main(){int q[N],front=0,rear=-1,ch,x;do{scanf("%d",&ch);if(ch==1){scanf("%d",&x);if(rear<N-1)q[++rear]=x;}else if(ch==2){if(front<=rear)printf("Processed=%d\n",q[front++]);}else if(ch==3){if(front<=rear)printf("Next=%d\n",q[front]);}else if(ch==4){for(int i=front;i<=rear;i++)printf("%d ",q[i]);puts("");}}while(ch!=5);return 0;}

#include <stdio.h>
#define N 50
int main(){int s[N],top=-1,ch,x;do{scanf("%d",&ch);if(ch==1){scanf("%d",&x);if(top<N-1)s[++top]=x;}else if(ch==2){if(top>=0)printf("Undo=%d\n",s[top--]);}else if(ch==3){if(top>=0)printf("Next=%d\n",s[top]);}else if(ch==4){for(int i=top;i>=0;i--)printf("%d ",s[i]);puts("");}}while(ch!=5);return 0;}

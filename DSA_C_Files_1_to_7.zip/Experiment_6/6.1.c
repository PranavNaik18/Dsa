#include <stdio.h>
struct Node{int data;struct Node*next;};
int main(){int n;scanf("%d",&n);printf("Array data storage=%zu bytes\n",n*sizeof(int));printf("Linked-list node size=%zu bytes\n",sizeof(struct Node));puts("Array has fixed capacity; linked list allocates nodes dynamically.");return 0;}

#include <stdio.h>
struct Node{int data;struct Node*next;};
int main(){int n;scanf("%d",&n);printf("Array storage=%zu bytes\n",n*sizeof(int));printf("Linked-list nodes=%zu bytes (excluding allocator overhead)\n",n*sizeof(struct Node));return 0;}

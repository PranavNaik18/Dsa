#include <stdio.h>
#include <stdlib.h>
struct Node{int job;struct Node*next;};struct Node*front=NULL,*rear=NULL;
void add(int x){struct Node*n=malloc(sizeof(*n));n->job=x;n->next=NULL;if(!rear)front=rear=n;else{rear->next=n;rear=n;}}
void printJob(){if(!front)puts("Queue Empty");else{struct Node*t=front;printf("Printing job %d\n",t->job);front=t->next;if(!front)rear=NULL;free(t);}}
int main(){int c,x;do{printf("1 Add 2 Print 3 Display 4 Exit: ");scanf("%d",&c);if(c==1){scanf("%d",&x);add(x);}else if(c==2)printJob();else if(c==3)for(struct Node*t=front;t;t=t->next)printf("%d ",t->job),printf("");}while(c!=4);return 0;}

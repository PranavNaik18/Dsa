#include <stdio.h>
int match(char a,char b){return(a=='('&&b==')')||(a=='['&&b==']')||(a=='{'&&b=='}');}
int main(){char s[200],st[200];int top=-1,ok=1;scanf("%199s",s);for(int i=0;s[i];i++){if(s[i]=='('||s[i]=='['||s[i]=='{')st[++top]=s[i];else if(s[i]==')'||s[i]==']'||s[i]=='}'){if(top<0||!match(st[top--],s[i])){ok=0;break;}}}if(top!=-1)ok=0;puts(ok?"Balanced Parentheses":"Not Balanced Parentheses");return 0;}

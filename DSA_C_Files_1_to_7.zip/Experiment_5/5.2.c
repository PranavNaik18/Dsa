#include <stdio.h>
#include <string.h>
#include <ctype.h>
int p(char c){if(c=='^')return 3;if(c=='*'||c=='/')return 2;if(c=='+'||c=='-')return 1;return 0;}
int main(){char in[100],rev[100],out[100],s[100];int n,k=0,t=-1;scanf("%99s",in);n=strlen(in);for(int i=0;i<n;i++){rev[i]=in[n-1-i];if(rev[i]=='(')rev[i]=')';else if(rev[i]==')')rev[i]='(';}for(int i=0;i<n;i++){char c=rev[i];if(isalnum(c))out[k++]=c;else if(c=='(')s[++t]=c;else if(c==')'){while(t>=0&&s[t]!='(')out[k++]=s[t--];if(t>=0)t--;}else{while(t>=0&&s[t]!='('&&p(s[t])>p(c))out[k++]=s[t--];s[++t]=c;}}while(t>=0)out[k++]=s[t--];for(int i=0;i<k/2;i++){char x=out[i];out[i]=out[k-1-i];out[k-1-i]=x;}out[k]='\0';printf("Prefix=%s\n",out);return 0;}

#include <stdio.h>
#include <ctype.h>
#define MAX 100
int main(){char exp[MAX],v;int val[26]={0},st[MAX],top=-1,n,x;scanf("%99s",exp);scanf("%d",&n);for(int i=0;i<n;i++){scanf(" %c%d",&v,&x);val[v-'a']=x;}for(int i=0;exp[i];i++){char c=exp[i];if(islower(c))st[++top]=val[c-'a'];else{int b=st[top--],a=st[top--];if(c=='+')st[++top]=a+b;else if(c=='-')st[++top]=a-b;else if(c=='*')st[++top]=a*b;else if(c=='/')st[++top]=a/b;else st[++top]=a%b;}}printf("Result=%d\n",st[top]);return 0;}

#include <stdio.h>
int main(){int r,c;scanf("%d%d",&r,&c);printf("2-D storage = %d integers\n1-D mapped storage = %d integers\n",r*c,r*c);puts("For a dense matrix, both store the same number of values.");return 0;}

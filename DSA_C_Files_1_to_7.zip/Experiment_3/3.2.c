#include <stdio.h>
int main(){int A[400],B[400],r,c;scanf("%d%d",&r,&c);for(int i=0;i<r*c;i++)scanf("%d",&A[i]);for(int i=0;i<r*c;i++)scanf("%d",&B[i]);for(int i=0;i<r;i++){for(int j=0;j<c;j++)printf("%d ",A[i*c+j]+B[i*c+j]);puts("");}return 0;}

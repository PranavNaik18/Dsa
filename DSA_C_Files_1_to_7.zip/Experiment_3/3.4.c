#include <stdio.h>
int main(){int n,a[5050],k=0,x;scanf("%d",&n);for(int i=0;i<n;i++)for(int j=0;j<=i;j++){scanf("%d",&x);a[k++]=x;}printf("1-D: ");for(int i=0;i<k;i++)printf("%d ",a[i]);puts("");puts("0-based index formula: i*(i+1)/2 + j");return 0;}

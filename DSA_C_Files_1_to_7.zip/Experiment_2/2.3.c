#include <stdio.h>
struct Employee{int id;char name[30];float salary;};
int main(){struct Employee e[100],t;int n;scanf("%d",&n);for(int i=0;i<n;i++)scanf("%d %29s %f",&e[i].id,e[i].name,&e[i].salary);for(int i=0;i<n-1;i++)for(int j=0;j<n-1-i;j++)if(e[j].salary>e[j+1].salary){t=e[j];e[j]=e[j+1];e[j+1]=t;}for(int i=0;i<n;i++)printf("%d %s %.2f\n",e[i].id,e[i].name,e[i].salary);return 0;}

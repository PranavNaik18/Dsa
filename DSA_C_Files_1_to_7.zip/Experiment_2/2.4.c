#include <stdio.h>
long bubble(int a[],int n){long c=0;for(int i=0;i<n-1;i++)for(int j=0;j<n-1-i;j++){c++;if(a[j]>a[j+1]){int t=a[j];a[j]=a[j+1];a[j+1]=t;}}return c;}
long selection(int a[],int n){long c=0;for(int i=0;i<n-1;i++){int m=i;for(int j=i+1;j<n;j++){c++;if(a[j]<a[m])m=j;}int t=a[i];a[i]=a[m];a[m]=t;}return c;}
long insertion(int a[],int n){long c=0;for(int i=1;i<n;i++){int x=a[i],j=i-1;while(j>=0){c++;if(a[j]>x)a[j+1]=a[j],j--;else break;}a[j+1]=x;}return c;}
int main(){int a[100],b[100],c[100],n;scanf("%d",&n);for(int i=0;i<n;i++)scanf("%d",&a[i]);for(int i=0;i<n;i++)b[i]=c[i]=a[i];printf("Bubble=%ld\nSelection=%ld\nInsertion=%ld\n",bubble(a,n),selection(b,n),insertion(c,n));return 0;}

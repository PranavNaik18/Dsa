#include <stdio.h>
#include <string.h>
#define MAX 50
int main(){char s[MAX][100],x[100];int top=-1,ch;do{printf("\n1.Push 2.Pop 3.Peek 4.Display 5.Exit: ");scanf("%d",&ch);if(ch==1){if(top==MAX-1)puts("Stack Overflow");else{printf("Action: ");scanf(" %99[^\n]",x);strcpy(s[++top],x);}}else if(ch==2){if(top==-1)puts("Stack Underflow");else printf("Undo: %s\n",s[top--]);}else if(ch==3){if(top==-1)puts("Empty");else printf("Next: %s\n",s[top]);}else if(ch==4)for(int i=top;i>=0;i--)puts(s[i]);}while(ch!=5);return 0;}

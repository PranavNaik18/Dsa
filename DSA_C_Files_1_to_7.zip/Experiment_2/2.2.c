#include <stdio.h>
#define MAX 50
int main(){int q[MAX],front=0,rear=-1,ch,job;do{printf("\n1.Enqueue 2.Dequeue 3.Peek 4.Display 5.Exit: ");scanf("%d",&ch);if(ch==1){if(rear==MAX-1)puts("Queue Full");else{printf("Job ID: ");scanf("%d",&job);q[++rear]=job;}}else if(ch==2){if(front>rear)puts("Queue Empty");else printf("Processed: %d\n",q[front++]);}else if(ch==3){if(front>rear)puts("Queue Empty");else printf("Next: %d\n",q[front]);}else if(ch==4){for(int i=front;i<=rear;i++)printf("%d ",q[i]);puts("");}}while(ch!=5);return 0;}

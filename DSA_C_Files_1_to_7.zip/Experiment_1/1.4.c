#include <stdio.h>
int recursive(int a[],int l,int h,int x){if(l>h)return -1;int m=(l+h)/2;if(a[m]==x)return m;if(a[m]<x)return recursive(a,m+1,h,x);return recursive(a,l,m-1,x);}
int iterative(int a[],int n,int x){int l=0,h=n-1;while(l<=h){int m=(l+h)/2;if(a[m]==x)return m;if(a[m]<x)l=m+1;else h=m-1;}return -1;}
int main(){int a[100],n,x;scanf("%d",&n);for(int i=0;i<n;i++)scanf("%d",&a[i]);scanf("%d",&x);printf("Iterative=%d\nRecursive=%d\n",iterative(a,n,x),recursive(a,0,n-1,x));return 0;}

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int linear(int a[],int n,int x){for(int i=0;i<n;i++)if(a[i]==x)return i;return -1;}
int binary(int a[],int n,int x){int l=0,h=n-1;while(l<=h){int m=(l+h)/2;if(a[m]==x)return m;if(a[m]<x)l=m+1;else h=m-1;}return -1;}
int main(){int sizes[]={1000,10000,100000,500000};for(int z=0;z<4;z++){int n=sizes[z],*a=malloc(n*sizeof(int));for(int i=0;i<n;i++)a[i]=i;clock_t t=clock();for(int k=0;k<1000;k++)linear(a,n,n-1);double x=(double)(clock()-t)/CLOCKS_PER_SEC;t=clock();for(int k=0;k<1000;k++)binary(a,n,n-1);double y=(double)(clock()-t)/CLOCKS_PER_SEC;printf("n=%d Linear=%f sec Binary=%f sec\n",n,x,y);free(a);}return 0;}

#include <stdio.h>
#include <string.h>
struct Student{char usn[20];char name[50];};
int main(){struct Student s[100];int n;char key[20];printf("Enter number of students: ");scanf("%d",&n);for(int i=0;i<n;i++){printf("USN Name: ");scanf("%19s %49s",s[i].usn,s[i].name);}printf("Enter USN: ");scanf("%19s",key);for(int i=0;i<n;i++)if(strcmp(s[i].usn,key)==0){printf("USN: %s\nName: %s\n",s[i].usn,s[i].name);return 0;}puts("Record not found");return 0;}
